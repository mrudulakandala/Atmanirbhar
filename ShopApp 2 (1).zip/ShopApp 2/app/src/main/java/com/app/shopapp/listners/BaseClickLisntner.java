package com.app.shopapp.listners;

public interface BaseClickLisntner {
    void onItemClickLisnter(int pos);
}
